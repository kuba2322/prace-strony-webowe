<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zadania na lipiec</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
    <div class="baner1">
        <img alt="lipiec" src="logo1.png">
    </div>
    <div class="baner2">
        <h1>TERMINARZ</h1>
        <p>najbliższe zadania

        <?php
$serwer = 'localhost';
$uzytkownik = 'root';
$password = '';
$dbname = 'terminarz';

$db = mysqli_connect($serwer, $uzytkownik, $password, $dbname);
$q = 'SELECT DISTINCT wpis FROM zadania WHERE dataZadania BETWEEN "2020-07-01" AND "2020-07-07" AND wpis <> "";';
$r = mysqli_query($db, $q);
$zadania = "";
while($row = mysqli_fetch_array($r)) {

$zadania .= $row["wpis"] . "; ";
}
echo $zadania;
 
?>
</p>
    </div>
</header>
<main>

<?php

$q = 'SELECT dataZadania, wpis FROM `zadania` WHERE miesiac = "lipiec";';
$r = mysqli_query($db, $q);
 
while($row = mysqli_fetch_array($r)) {
    echo '<section class ="kalendarz">
            <h6>' .$row["dataZadania"].'</h6> 
            <p>' .$row["wpis"].'</p>
            </section>';
}
?>

    <h6> 

</div>
</main>
    

    <div class="stopka">
        <a href="sierpien.html">Terminarz na sierpnień</a>
        <p>strone Wykonał: kuba k</p>
    </div>
</body>
</html>